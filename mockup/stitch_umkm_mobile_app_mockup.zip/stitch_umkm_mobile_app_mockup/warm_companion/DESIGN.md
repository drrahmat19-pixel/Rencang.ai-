---
name: Warm Companion
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#404944'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#707974'
  outline-variant: '#bfc9c2'
  surface-tint: '#2f6954'
  primary: '#003526'
  on-primary: '#ffffff'
  primary-container: '#0e4d3a'
  on-primary-container: '#82bda4'
  inverse-primary: '#98d3b9'
  secondary: '#176b4b'
  on-secondary: '#ffffff'
  secondary-container: '#a1f0c7'
  on-secondary-container: '#1d704f'
  tertiary: '#3d2a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#593f00'
  on-tertiary-container: '#d5aa57'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b3efd5'
  primary-fixed-dim: '#98d3b9'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#13503d'
  secondary-fixed: '#a4f3ca'
  secondary-fixed-dim: '#88d6af'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdea6'
  tertiary-fixed-dim: '#edc06a'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5d4200'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
  deep-forest: '#093C30'
  canvas-ivory: '#F8F5EC'
  card-sand: '#EADDC8'
  pure-white: '#FFFFFF'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

# RENCANG AI — DESIGN SYSTEM & VISUAL IDENTITY

> **File:** `design.md`  
> **Version:** 1.0 — Draft for implementation  
> **Date:** 9 October 2026  
> **Brand:** Rencang AI  
> **Mascot / AI Persona:** Kang Bisa  
> **Tagline:** *Rencang Usaha, Biar Kang Bisa yang Bantu.*  
> **Primary audience:** UMKM Indonesia, initially West Java

## 1. Design North Star
Rencang AI is a friendly, reliable, affordable AI-powered business companion for Indonesian UMKM. Mobile-first, warm copy, Plus Jakarta Sans, forest green and warm ivory with gold accent.

## 4. Colour Palette
- `brand.green.900`: `#0E4D3A` (Primary brand green)
- `brand.green.950`: `#093C30` (Hero deep green)
- `brand.gold.500`: `#D4A956` (Gold accent)
- `brand.ivory.50`: `#F8F5EC` (Warm canvas background)
- `brand.leaf.500`: `#2E7D5B` (Secondary leaf green)
- `brand.sand.200`: `#EADDC8` (Warm cards)
- `neutral.charcoal.900`: `#1F2937` (Main text)
- `neutral.white`: `#FFFFFF`

## 5. Typography
- Primary: Plus Jakarta Sans, fallback Inter, system-ui, sans-serif
- Tone: Warm, respectful, Bahasa Indonesia everyday language (Bapak/Ibu)
