# RENCANG AI — DESIGN SYSTEM & VISUAL IDENTITY

> **File:** `design.md`  
> **Version:** 1.0 — Draft for implementation  
> **Date:** 9 October 2026  
> **Brand:** Rencang AI  
> **Mascot / AI Persona:** Kang Bisa  
> **Tagline:** *Rencang Usaha, Biar Kang Bisa yang Bantu.*  
> **Primary audience:** UMKM Indonesia, initially West Java

## 1. Design North Star

**Rencang AI is a friendly, reliable, affordable AI-powered business companion.** The product must feel as approachable as a helpful neighbour and as dependable as a professional business tool. Its interface is designed for busy UMKM owners, including first-time CRM users.

### Design principles

1. **Langsung bisa dipakai:** the primary task must be visible immediately; avoid lengthy configuration.
2. **Ramah, bukan kekanak-kanakan:** warm copy, confident typography, restrained decoration.
3. **Jelas sebelum canggih:** explain the outcome of AI actions and let users confirm sensitive actions.
4. **Mobile-first:** WhatsApp and smartphone workflows are primary, not secondary.
5. **Kepercayaan melalui transparansi:** show sync status, action history, data provenance, and clear errors.
6. **Local in voice, universal in usability:** Indonesian-first with optional light Sundanese flavour; never require knowledge of Sundanese.
7. **Aksesibel:** readable contrast, comfortable targets, keyboard access, and reduced-motion support.

## 2. Brand Architecture

| Layer | Name | Role |
|---|---|---|
| Master brand | **Rencang AI** | Product ecosystem and company-facing identity |
| AI persona | **Kang Bisa** | Conversational helper, onboarding and assistance |
| Core platform | **Rencang CRM** | Customer database, conversations, follow-ups and automation |
| Proposed module | **Rencang Catat** | Simple transaction capture and financial summaries |
| Proposed programme | **Rencang Academy** | Education and UMKM community |

Module names beyond Rencang AI and Kang Bisa are **proposals**, not approved product names.

## 3. Logo System

### Concept

A stylised **R** combining connection, conversation, and organic growth. Its two forms suggest a companion helping a business move forward. Avoid overly literal robots or generic circuit-board motifs.

### Required assets

- `logo-primary-horizontal.svg` — icon + Rencang AI wordmark
- `logo-stacked.svg` — vertical layout
- `logo-symbol.svg` — symbol only
- `logo-mono-light.svg` and `logo-mono-dark.svg`
- `favicon.svg` and app icons at required platform sizes

### Usage

- Minimum clear space: at least **0.5× the symbol height** on all sides.
- Suggested minimum digital width: **140px** for full horizontal logo; **24px** for icon (verify legibility).
- Use light wordmark on dark green, dark green wordmark on ivory/white.
- Never stretch, rotate, add glow, replace brand colours arbitrarily, or place over busy photos without a solid overlay.
- **Important:** the reference blueprint is concept art. Do not trace a raster illustration into a final trademark without original vector refinement and legal review.

## 4. Colour Palette

### Primary

| Token | Hex | Purpose |
|---|---|---|
| `brand.green.900` | `#0E4D3A` | Primary brand green; logo, primary dark surfaces |
| `brand.green.950` | `#093C30` | Deep hero background, strong contrast |
| `brand.gold.500` | `#D4A956` | Gold accent, highlights, illustration |
| `brand.ivory.50` | `#F8F5EC` | Warm canvas and brand backgrounds |

### Secondary

| Token | Hex | Purpose |
|---|---|---|
| `brand.leaf.500` | `#2E7D5B` | Secondary green |
| `brand.forest.800` | `#174236` | Supporting dark green |
| `brand.sage.300` | `#A7C4B2` | Soft backgrounds, illustrations |
| `brand.sand.200` | `#EADDC8` | Warm neutral cards |
| `neutral.charcoal.900` | `#1F2937` | Main text |
| `neutral.gray.100` | `#E5E7EB` | Borders |
| `neutral.white` | `#FFFFFF` | White surfaces |

### Semantic colours (interface, not logo)

| Token | Hex | Meaning |
|---|---|---|
| `status.success` | `#18794E` | Completed, connected |
| `status.warning` | `#9A6700` | Attention required |
| `status.error` | `#B42318` | Failed, destructive |
| `status.info` | `#175CD3` | Informational |

**Accessibility rule:** Gold is primarily decorative; do not use small gold text on ivory/white. Validate actual foreground/background pairings against WCAG AA (4.5:1 normal text, 3:1 large text and essential UI graphics). Semantic colours must not be the only indicator of state.

## 5. Typography

- **Primary:** Plus Jakarta Sans, fallback `Inter, system-ui, sans-serif`.
- **Accent/editorial:** Lora, fallback `Georgia, serif` — optional, sparing use in brand campaigns, not dashboards.
- **Numbers:** use tabular numerals in prices, finance, metrics and tables.
- **Language:** Bahasa Indonesia by default; sentence case for UI labels.

| Style | Desktop | Mobile | Weight | Line-height |
|---|---:|---:|---:|---:|
| Display | 48px | 36px | 700 | 1.15 |
| H1 | 36px | 30px | 700 | 1.2 |
| H2 | 28px | 24px | 700 | 1.25 |
| H3 | 22px | 20px | 600 | 1.3 |
| Body | 16px | 16px | 400 | 1.6 |
| Body small | 14px | 14px | 400 | 1.5 |
| Caption | 12px | 12px | 500 | 1.4 |
| Button | 14–16px | 14–16px | 600 | 1.25 |

Never use a font size below 12px for essential UI content.

## 6. Kang Bisa — Character Identity

**Persona:** Indonesian Sundanese man, visually around 45–50, approachable, experienced, calm, slightly humorous, and technologically literate. He feels like a wise business companion, not a salesman.

### Visual direction

- Warm, natural smile; expressive but credible face.
- Dark green clothing with subtle West Java/Sundanese cultural cues.
- Clean contemporary presentation; avoid caricature or exaggerated stereotypes.
- Reference imagery may include a Sundanese headcloth, but do not make it mandatory in every context.
- Portraits: friendly eye-level framing, soft light, ivory or green background.
- Expressions: welcome, explain, success, thinking, gentle alert, support.

### Voice and copy

- Default address: **Bapak/Ibu** or user-preferred name; “Kang” is the persona's own title.
- Use concise everyday Indonesian. Occasional “mangga” is acceptable when culturally appropriate, never forced.
- Helpful: “Siap, Bu. Ada 12 pelanggan yang perlu ditindaklanjuti hari ini.”
- Transparent: “Kang Bisa sudah menyiapkan pesannya. Silakan periksa sebelum dikirim.”
- Error: “Koneksi WhatsApp sedang terputus. Data pelanggan tetap tersimpan. Yuk, sambungkan lagi.”
- Never claim an action was completed until the system confirms it.
- Never promise profit, financial accuracy, or fully autonomous operation without verification.

## 7. Illustration, Photography & Iconography

### Illustration

Rounded geometry, gentle organic forms, simplified UMKM scenes, small leaf/connection motifs, limited palette, and generous whitespace. Use illustrations to explain workflows, not decorate every screen.

### Photography

Realistic Indonesian micro-business environments: warung, culinary SMEs, salons, shops, service counters. Prioritise consented authentic imagery. Warm light, candid interactions, and real work over generic stock poses.

### Icons

- Preferred library: Lucide icons, 20px default, 1.75–2px stroke.
- Examples: `users`, `message-circle`, `receipt`, `chart-no-axes-column`, `workflow`, `settings`, `shield-check`.
- Always pair ambiguous icons with text labels; consistent stroke and optical sizing.

## 8. Layout & Spacing

Use a **4px base grid** with common steps: 4, 8, 12, 16, 24, 32, 48, 64px.

- Marketing content width: max 1200px.
- Dashboard content width: fluid, readable main columns.
- Desktop sidebar: 240–264px; collapse at tablet breakpoints.
- Mobile horizontal padding: 16px; desktop: 24–32px.
- Card radius: 16px; inputs/buttons: 10–12px; chips: full-pill.
- Cards: white on ivory/light-gray backgrounds; borders before heavy shadows.
- Tap targets: minimum 44×44px where practical.
- Breakpoints: `sm 640px`, `md 768px`, `lg 1024px`, `xl 1280px`.

## 9. UI Components

### Buttons

| Variant | Style | Usage |
|---|---|---|
| Primary | Deep green fill, white text | Main action: “Tambah pelanggan” |
| Secondary | White fill, green border/text | Alternative action |
| Accent | Gold fill, dark green text | Limited marketing CTAs, not every screen |
| Ghost | Transparent with hover surface | Toolbar actions |
| Destructive | Error red | Delete/revoke, always confirm |

States: default, hover, focus-visible, pressed, disabled, loading. Loading buttons retain width and announce status.

### Inputs

Visible labels (not placeholder-only), helper text, clear validation, input masks where appropriate, and error text near the field. Use `aria-describedby` for descriptions/errors.

### Cards

Title, meaningful status, one primary action, optional secondary details. Avoid dense cards with 4+ competing CTAs.

### Data tables

Sortable columns, search, filter, pagination, empty state, mobile card alternative. Financial values right-aligned with Indonesian number formatting.

### Feedback

Use toast for noncritical confirmation, inline banners for persistent issues, confirmation modal for destructive or externally visible actions, and skeletons for loading.

## 10. Key Screens & Information Architecture

### Navigation (MVP)

1. **Beranda** — today's overview, outstanding follow-ups, AI status.
2. **Percakapan** — WhatsApp/inbox, AI/human handoff, contact context.
3. **Pelanggan** — searchable customer memory and history.
4. **Otomasi** — approved rules, triggers, logs.
5. **Laporan** — customer/service metrics; financial data only if implemented.
6. **Pengaturan** — channel connection, team, permissions, billing.

### Dashboard home

Top: greeting + WhatsApp connection status. Then 3–4 actionable KPIs, priority tasks, latest customer activity, and a clearly labelled “Tanya Kang Bisa” assistant panel.

### Chat/Agentic CRM

Conversation list, message panel, customer context. Clearly mark **AI-generated**, **draft**, **waiting for approval**, **sent**, **failed**, and **human takeover**. Do not hide automated outbound actions.

### Photo-to-record workflow (proposed)

Upload photo → preview → extraction → user review/correction → save → confirmation. OCR/extraction must not silently post unverified financial entries.

### Onboarding

Choose business type → add business name → connect channel → import/create first customer → test a conversation → show first value. Allow skip for nonessential settings.

## 11. Accessibility & Trust

- WCAG 2.2 AA target for public website and app.
- Keyboard operability, visible focus rings, semantic labels, error recovery.
- Reduced-motion option and respect `prefers-reduced-motion`.
- Screen reader status updates for background AI tasks.
- Confirmation before bulk messaging, deleting customer records, changing financial records, or triggering costly external actions.
- Clear consent, access controls, audit history, and privacy policy for customer data.
- AI outputs and OCR may be inaccurate; give users edit/review controls.

## 12. Motion

- Micro-interactions: 120–180ms.
- Drawer/dialog transitions: 180–240ms.
- Prefer opacity and subtle transforms; avoid constant bouncing mascots.
- No animations required for task completion; never obscure error or loading states.

## 13. CSS Design Tokens

```css
:root {
  --brand-green-950: #093c30;
  --brand-green-900: #0e4d3a;
  --brand-green-800: #174236;
  --brand-green-500: #2e7d5b;
  --brand-gold-500: #d4a956;
  --brand-ivory-50: #f8f5ec;
  --brand-sage-300: #a7c4b2;
  --brand-sand-200: #eaddc8;

  --color-bg: #f8f5ec;
  --color-surface: #ffffff;
  --color-text: #1f2937;
  --color-text-muted: #4b5563;
  --color-border: #e5e7eb;
  --color-primary: #0e4d3a;
  --color-primary-hover: #093c30;
  --color-on-primary: #ffffff;
  --color-focus: #175cd3;
  --color-success: #18794e;
  --color-warning: #9a6700;
  --color-error: #b42318;

  --font-sans: 'Plus Jakarta Sans', Inter, system-ui, sans-serif;
  --font-editorial: Lora, Georgia, serif;
  --radius-input: 12px;
  --radius-card: 16px;
  --radius-pill: 9999px;
  --shadow-card: 0 4px 18px rgba(9, 60, 48, 0.07);
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-6: 24px;
  --space-8: 32px;
}

:focus-visible {
  outline: 3px solid var(--color-focus);
  outline-offset: 2px;
}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

### Suggested Tailwind mapping

Map CSS variables into semantic classes such as `bg-primary`, `text-primary`, `bg-surface`, `text-muted`, `border-default`, `rounded-card`. Components should consume semantic tokens rather than hard-coded hex values.

## 14. Brand Applications

### Landing page

Hero: “Usaha boleh kecil. Pelayanan tetap bisa pintar.” Subhead explains customer memory, chat assistance, and simple workflow. Primary CTA: **Coba Demo**. Secondary CTA: **Lihat Cara Kerja**. Show Kang Bisa, a realistic app screenshot, and a short 3-step explanation.

### WhatsApp presence

Logo-symbol avatar; display name “Rencang AI”. Clearly identify automated replies and provide a path to human support. Use consistent tone and never simulate a human identity deceptively.

### Mobile app

Simple green icon with original R mark, uncluttered home, prominent tasks and alerts, readable touch targets.

### Marketing templates

1080×1350 feed, 1080×1920 story, 1200×628 campaign graphic. One main message, one CTA, minimal copy, real UMKM situations, consistent logo safe area.

## 15. Brand Do / Don't

**Do:** prioritise readability; show actual customer outcomes; keep the green/ivory foundation; use Kang Bisa sparingly at meaningful moments; explain AI decisions and statuses.

**Don't:** fill every screen with gold; overuse Sundanese expressions; make Kang Bisa a cartoon caricature; imply AI never makes mistakes; claim 50% savings without verified comparison; use unreadable text over photography.

## 16. Handoff & Acceptance Checklist

- [ ] Original vector logo approved, including monochrome and icon variants.
- [ ] Trademark and domain availability checked independently.
- [ ] Kang Bisa portrait/illustration assets licensed and approved.
- [ ] Typography licensing and hosting strategy confirmed.
- [ ] Colour contrast tested on actual UI combinations.
- [ ] Core UI components built with states and keyboard support.
- [ ] Mobile-first dashboard and chat screens tested with UMKM users.
- [ ] AI action approval, logs, and failure states implemented.
- [ ] Financial capture workflow includes human verification.
- [ ] Product claims and package pricing validated before launch.

## 17. Status & Governance

This file translates the team's initial brand conversation and visual concept into an actionable **design specification**. It is **not** evidence that the logo is legally cleared, that features are implemented, or that the palette has passed contrast testing. Final asset approval belongs to the four founders, with one designated brand owner maintaining version control.

**Core brand sentence:** *Rencang AI membantu UMKM bekerja lebih rapi dan melayani pelanggan lebih baik, dengan Kang Bisa sebagai sahabat digital yang mudah diajak bicara.*
